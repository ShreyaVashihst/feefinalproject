import React, { useState } from "react";

const Third =() =>{

    const [isHovered, setIsHovered] = useState(false);
    return(
        <>
        <div className="image-grid" >
    
    <div>
     
      <div className="image span-1" onMouseEnter={() => setIsHovered(true)} onMouseLeave={() => setIsHovered(false)}>
        <img className="image span-1" src="img/summer/picture 1.png" alt="Your Image" />
        {isHovered && (
    <div>
      <a href="#" className="view-button">View</a>
      <img className="Shape-30" src="img/Shape 30.png" alt="" />
    </div>
  )}
      </div>
      <div className="image span-1" onMouseEnter={() => setIsHovered(true)} onMouseLeave={() => setIsHovered(false)}>
        <img className="image span-1" src="img/summer/picture 2.png" alt="Your Image" />
        {isHovered && <div>
      <a href="#" className="view-button">View</a>
      <img className="Shape-30" src="img/Shape 30.png" alt="" />
    </div>}
      </div>
      <div className="image span-3" onMouseEnter={() => setIsHovered(true)} onMouseLeave={() => setIsHovered(false)}>
        <img className="image span-3" src="img/summer/picture 3.png" alt="Your Image" />
        {isHovered && <div>
      <a href="#" className="view-button">View</a>
      <img className="Shape-30" src="img/Shape 30.png" alt="" />
    </div>}
      </div>
      </div>
      <div id="Second">
      <div className="image span-3" onMouseEnter={() => setIsHovered(true)} onMouseLeave={() => setIsHovered(false)}>
        <img className="image span-3" src="img/summer/picture 4.png" alt="Your Image" />
        {isHovered && <div>
      <a href="#" className="view-button">View</a>
      <img className="Shape-30" src="img/Shape 30.png" alt="" />
    </div>}
      </div>
      <div className="image span-1" onMouseEnter={() => setIsHovered(true)} onMouseLeave={() => setIsHovered(false)}>
        <img className="image span-1" src="img/summer/picture 5.png" alt="Your Image" />
        {isHovered && <div>
      <a href="#" className="view-button">View</a>
      <img className="Shape-30" src="img/Shape 30.png" alt="" />
    </div>}
      </div>
      <div className="image span-1" onMouseEnter={() => setIsHovered(true)} onMouseLeave={() => setIsHovered(false)}>
        <img className="image span-1" src="img/summer/picture 6.png" alt="Your Image" />
        {isHovered &&<div>
      <a href="#" className="view-button">View</a>
      <img className="Shape-30" src="img/Shape 30.png" alt="" />
    </div>}
      </div>
      </div>
      <div>
      <div className="image span-1" onMouseEnter={() => setIsHovered(true)} onMouseLeave={() => setIsHovered(false)}>
        <img className="image span-1" src="img/summer/picture 7.png" alt="Your Image" />
        {isHovered &&<div>
      <a href="#" className="view-button">View</a>
      <img className="Shape-30" src="img/Shape 30.png" alt="" />
    </div>}
        </div>
      <div className="image span-1" onMouseEnter={() => setIsHovered(true)} onMouseLeave={() => setIsHovered(false)}>
        <img className="image span-1" src="img/summer/picture 8.png" alt="Your Image" />
        {isHovered &&<div>
      <a href="#" className="view-button">View</a>
      <img className="Shape-30" src="img/Shape 30.png" alt="" />
    </div>}
      </div>
      <div className="image span-2" onMouseEnter={() => setIsHovered(true)} onMouseLeave={() => setIsHovered(false)}>
        <img className="image span-2" src="img/summer/picture 9.png" alt="Your Image" />
        {isHovered &&<div>
      <a href="#" className="view-button">View</a>
      <img className="Shape-30" src="img/Shape 30.png" alt="" />
    </div>}
      </div>
      <div className="image span-1" onMouseEnter={() => setIsHovered(true)} onMouseLeave={() => setIsHovered(false)}>
        <img className="image span-1" src="img/summer/picture 10.png" alt="Your Image" />
        {isHovered &&<div>
      <a href="#" className="view-button">View</a>
      <img className="Shape-30" src="img/Shape 30.png" alt="" />
    </div>}
      </div>
      </div>
    </div>
        </>
    )
}
export default Third