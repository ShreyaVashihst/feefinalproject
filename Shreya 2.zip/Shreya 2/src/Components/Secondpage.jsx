import React from "react";

const Second = () =>{
    return(
<> 
<div className="season-btn" id="First">
    <button className="spring">SPRING</button>
    <button className="summer">SUMMER</button>
    <button className="autumn">AUTUMN</button>
    <button className="winter">WINTER</button>
  </div>
</>
    )
}
export default Second