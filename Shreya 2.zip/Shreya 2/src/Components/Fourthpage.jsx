import React from "react";

const Fourth =() =>{
    return(
<>
  <div className="load-more">
    <button>LOAD MORE CLOTHES</button>
  </div>
  <div className="trends" id="Third">
    <div className="img">
      <img src="img/summer/tends.png" alt="" />
    </div>
    <div className="headline">
      <h1>TOP 20 TRENDS FOR</h1>
      <h2>SPRING/SUMMER</h2>
      <div className="highlights">
        <p>
          With Seventies influences from Saturday night fever to hippy deluxe, a
          khaki nod to military style alongside nautical accents, experiments
          with transparency, patchworks of vintage prints and mix &amp; match
          approach to volume and fabric, for Summer 2015 we're set to see
          contrast take center stage. Stay a step ahead as we present a round-up
          of the runaway trends set to take Spring/Summer 2015 by storm.
        </p>
        
      </div>
      <div className="more">
        <button>MORE</button>
      </div>
    </div>
    <div className="dots">
          <div className="dot-on" />
          <div className="dot-off" />
          <div className="dot-off" />
        </div>
  </div>
</>
    )
}
export default Fourth