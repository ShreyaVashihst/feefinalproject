import React from "react";

const Fifth =() =>{
    return(
<>
     <div className="sponsor">
    <img src="img/sponsor1.png" alt="" />
    <img src="img/sponsor2.png" alt="" />
    <img src="img/sponsor3.png" alt="" />
    <img src="img/sponsor4.png" alt="" />
    <img src="img/sponsor5.png" alt="" />
    <img src="img/sponsor6.png" alt="" />
  </div>
  <div className="footer">
    <div className="footer-links">
      <ul>
        <li>
          <a href="">HOME</a>
        </li>
        <li>
          <a href="">ABOUT</a>
        </li>
        <li>
          <a href="">CONTACT</a>
        </li>
      </ul>
      <h1>Image rights belong to their respective owners.</h1>
    </div>
    <div className="social">
      <div className="social-img">
        <img src="img/pinterest.png" alt="" />
        <img src="img/facebook.png" alt="" />
        <img src="img/twitter.png" alt="" />
      </div>
      <div className="mails">
        <input
          type="email"
          name=""
          id=""
          placeholder="Get discount codes in your inbox"
        />
        <button>SUBSCRIBE</button>
      </div>
    </div>
  </div>
</>
    )
}
export default Fifth