import React, { useState, useEffect }  from "react";

const First = ()=>{
  
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const handleToggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  useEffect(() => {
   
    const hamburger = document.querySelector(".hamburger");
    hamburger.addEventListener("click", handleToggleMenu);

   
    return () => {
      hamburger.removeEventListener("click", handleToggleMenu);
    };
  }, [isMenuOpen]); 

    return(
        <>
  <div className="main">
    <div className="header">
      <div className="left">
        <img className="hamburger" src="img/burger.png" alt="" />
        <div className={`links ${isMenuOpen ? "active" : ""}`}>
              <div className="menu">
                <ul>
                  <li>
                    <a href="#First">TRENDS</a>
                  </li>
                  <li>
                    <a href="#Second">COLLECTIONS</a>
                  </li>
                  <li>
                    <a href="#Third">DESIGNERS</a>
                  </li>
                </ul>
              </div>
        </div>
      </div>
      <div className="right">
        <ul>
          <li><a href="#">SEARCH</a></li>
          <li>
            <a href="#"><img src="img/search.svg" alt="" /></a>
          </li>
          <li>
            <a href=""><img src="img/cart.png" alt="" /></a>
          </li>
          <li>
            <a href=""><img src="img/avatar.png" alt="" /></a>
          </li>
        </ul>
      </div>
    </div>
    <div className="main-picture">
      <div className="season-text">
        <h1>NEW</h1>
        <h2>SEASON</h2>
        <h3>LOOKS</h3>
      </div>
      <div className="auntie">
        <img src="img/main picture.png" alt="" />
      </div>
      <div className="arrow">
        <img src="img/prev.png" alt="" />
        <img src="img/next.png" alt="" />
      </div>
    </div>
  </div>
  
</>

    )
}

export default First